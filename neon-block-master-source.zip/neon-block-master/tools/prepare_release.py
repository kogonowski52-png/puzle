#!/usr/bin/env python3
"""Validate public release settings; build only with the owner's upload key."""
import argparse, html, ipaddress, json, os, re, subprocess, sys, time
from pathlib import Path
from urllib.parse import urlsplit
ROOT=Path(__file__).resolve().parents[1]
TEST_PUBLISHER='3940256099942544'

def validate(config):
    errors=[]
    allowed={"mode","publisher_name","contact_email","privacy_url","website_url","audience","admob"}
    if set(config)-allowed: errors.append("Unknown configuration fields rejected; never add passwords or signing credentials")
    if config.get('mode')!='production': errors.append('mode must be production')
    for key in ('publisher_name','contact_email','privacy_url','website_url'):
        if not isinstance(config.get(key),str) or not config[key].strip(): errors.append(f'{key}: required')
    email=config.get('contact_email','')
    if not isinstance(email,str) or not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+',email): errors.append('contact_email: valid public email required')
    for key in ('privacy_url','website_url'):
        try: u=urlsplit(config.get(key,''))
        except (ValueError,TypeError,AttributeError): errors.append(f'{key}: invalid URL');continue
        if u.scheme!='https' or not u.hostname or u.username or u.password or u.hostname in ('localhost','example.com','example.net','example.org') or u.hostname.endswith('.example.com'):
            errors.append(f'{key}: public HTTPS URL required')
        if u.hostname:
            try:
                if not ipaddress.ip_address(u.hostname).is_global: errors.append(f'{key}: private/local address rejected')
            except ValueError: pass
    if config.get('audience') not in ('16+','18+'):
        errors.append('audience: choose 16+ or 18+ only if this matches actual intended users; younger/mixed audiences require a separate age-appropriate implementation')
    ads=config.get('admob',{})
    if not isinstance(ads,dict): ads={}
    if set(ads)-{"app_id","rewarded_id","interstitial_id"}: errors.append("Unknown AdMob configuration fields rejected")
    publishers=[]
    for name,sep in [('app_id','~'),('rewarded_id','/'),('interstitial_id','/')]:
        value=ads.get(name,'')
        match=re.fullmatch(r'ca-app-pub-(\d{16})'+re.escape(sep)+r'\d{10}',value) if isinstance(value,str) else None
        if not match or match[1]==TEST_PUBLISHER: errors.append(f'admob.{name}: production ID required (Google test IDs rejected)')
        else: publishers.append(match[1])
    if len(set(publishers))>1: errors.append('All AdMob IDs must belong to the same publisher')
    if ads.get('rewarded_id')==ads.get('interstitial_id'): errors.append('Rewarded and Interstitial must use separate ad units')
    return errors

def website(config,out):
    out.mkdir(parents=True,exist_ok=True)
    source=(ROOT/'store/privacy.html').read_text()
    publisher=html.escape(config['publisher_name']);email=html.escape(config['contact_email'])
    source=source.replace('[UZUPEŁNIJ NAZWĘ I ADRES]',publisher).replace('[UZUPEŁNIJ E-MAIL]',email).replace('[COMPLETE NAME, ADDRESS AND EMAIL BEFORE PUBLICATION]',publisher+' — '+email)
    source=source.replace('Dokument do uzupełnienia przed publikacją. ','').replace(' Opublikuj ten dokument pod publicznym adresem HTTPS i podaj go w Google Play oraz AdMob UMP.','')
    source=source.replace('Wersja deweloperska korzysta z identyfikatorów testowych.','').replace('Developer builds use test ad identifiers.','')
    source=source.replace('Wydawca musi przed publikacją określić grupę wiekową i skonfigurować odpowiednie flagi SDK oraz formularze UMP. Ten szablon nie stanowi deklaracji zgodności z zasadami Families ani przeznaczenia dla dzieci.',f'Gra przeznaczona jest dla odbiorców {html.escape(config["audience"])}. Nie jest kierowana do dzieci. Formularze zgód i dostawców reklam skonfigurowano w Google UMP; ich działanie należy zweryfikować na urządzeniu.')
    source=source.replace('The publisher must determine the target age group, appropriate SDK flags, lawful bases and consent messages before release, and keep the Play Data safety disclosure accurate.',f'The intended audience is {html.escape(config["audience"])}. This game is not directed at children. The publisher must keep consent configuration and the Play Data safety disclosure accurate.')
    # The generated text describes the chosen configuration; never certify legal or SDK compliance.
    source=source.replace('Formularze zgód i dostawców reklam skonfigurowano w Google UMP; ich działanie należy zweryfikować na urządzeniu.','Zgody obsługuje Google UMP zgodnie z ustawieniami wydawcy.')
    (out/'privacy.html').write_text(source)
    pub=config['admob']['app_id'].split('pub-')[1].split('~')[0]
    (out/'app-ads.txt').write_text(f'google.com, pub-{pub}, DIRECT, f08c47fec0942fa0\n')
    (out/'index.html').write_text(f'<!doctype html><html lang="pl"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Neon Block Master</title><body style="background:#080d1e;color:#eff3ff;font:20px system-ui;max-width:760px;margin:60px auto;padding:24px"><h1>Neon Block Master</h1><p>Classic · Time Attack · Daily Challenge</p><p>{publisher} · <a href="mailto:{email}">{email}</a></p><p><a href="privacy.html">Polityka prywatności / Privacy policy</a></p></body></html>')

def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config',type=Path,default=ROOT/'config/publishing.json')
    parser.add_argument('--check',action='store_true')
    parser.add_argument('--build',action='store_true')
    parser.add_argument('--website',type=Path,help='Generate site and app-ads.txt in this directory after validation')
    args=parser.parse_args(argv)
    try: config=json.loads(args.config.read_text())
    except (OSError,ValueError):
        print('Missing/invalid config. Copy config/publishing.example.json to config/publishing.json and fill public data.',file=sys.stderr);return 2
    if not isinstance(config,dict): print('Config must be an object.',file=sys.stderr);return 2
    errors=validate(config)
    if errors:
        print('Release blocked:\n'+'\n'.join('- '+e for e in errors),file=sys.stderr);return 2
    print('Public configuration: valid. This does not verify account ownership, HTTPS hosting, UMP setup or current Play policies.')
    if args.website: website(config,args.website)
    if not args.build: return 0
    required=['GODOT_ANDROID_KEYSTORE_RELEASE_PATH','GODOT_ANDROID_KEYSTORE_RELEASE_USER','GODOT_ANDROID_KEYSTORE_RELEASE_PASSWORD']
    missing=[key for key in required if not os.environ.get(key)]
    if missing: print('Signing unavailable; set securely: '+', '.join(missing),file=sys.stderr);return 2
    key=Path(os.environ[required[0]])
    if not key.is_file(): print('Upload keystore file is unavailable.',file=sys.stderr);return 2
    # Refuse the known test key. Check certificate fingerprint, never print passwords.
    password_env='GODOT_ANDROID_KEYSTORE_RELEASE_PASSWORD'
    result=subprocess.run(['keytool','-list','-v','-keystore',str(key),'-storepass:env',password_env,'-alias',os.environ[required[1]]],capture_output=True,text=True)
    if result.returncode or 'CN=Android Debug' in result.stdout:
        print('A valid non-debug upload key is required.',file=sys.stderr);return 2
    paths=[ROOT/'assets/app_config.json',ROOT/'project.godot']
    backups={p:p.read_bytes() for p in paths}
    started=time.time()
    try:
        paths[0].write_text(json.dumps(config,indent=2,ensure_ascii=False)+'\n')
        subprocess.run(['godot','--headless','--path',str(ROOT),'--export-release','Android Production'],cwd=ROOT,check=True)
        artifact=ROOT/'builds/neon-block-master-production.aab'
        if not artifact.is_file() or artifact.stat().st_mtime<started: raise RuntimeError('No fresh AAB was created')
        import zipfile
        with zipfile.ZipFile(artifact) as z:
            if not any(n.startswith('META-INF/') and n.endswith(('.RSA','.EC','.DSA')) for n in z.namelist()): raise RuntimeError('AAB is unsigned')
        subprocess.run(['jarsigner','-verify',str(artifact)],check=True,stdout=subprocess.DEVNULL)
        print('Built production AAB. Complete device tests, consent tests and Play Console review before publication.')
    finally:
        for path,contents in backups.items(): path.write_bytes(contents)
    return 0
if __name__=='__main__': sys.exit(main())
