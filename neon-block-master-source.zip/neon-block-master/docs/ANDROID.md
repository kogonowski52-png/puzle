# Android i publikacja

Aktualny przewodnik dla właściciela: [PUBLIKACJA-KROK-PO-KROKU.md](PUBLIKACJA-KROK-PO-KROKU.md). Identyfikatory i tryb są teraz w `assets/app_config.json`; produkcyjny plik tworzy `tools/prepare_release.py` z lokalnego `config/publishing.json`, a po eksporcie przywraca testowy. Poniższe wartości to testowe ID Google.

## Narzędzia i eksport

Zweryfikowany silnik: Godot 4.6.3 official (`7d41c59c4`). Zainstaluj oficjalne szablony eksportu 4.6.3. SHA-512 archiwum użytego w chmurze zweryfikowano względem `SHA512-SUMS.txt` z oficjalnego wydania Godot.

Wymagany pełny JDK (z `javac`, nie samo JRE); w tej maszynie JDK 21.0.12.1. Ustaw jego katalog w **Editor Settings → Export → Android → Java SDK Path**. Oficjalny szablon Godot 4.6.3 używa Gradle 8.11.1, Android Gradle Plugin 8.6.1, compile/target SDK **36**, build-tools **36.1.0**. Starsza strona dokumentacji gałęzi 4.6 podawała API 35 — do budowy używamy wartości z faktycznie pobranego szablonu 4.6.3.

Android SDK:

```sh
sdkmanager "platform-tools" "platforms;android-36" "build-tools;36.1.0"
```

Wskaż SDK w ustawieniach edytora. Zainstaluj szablon: **Project → Install Android Build Template**. Katalog `android/build/` jest generowany i ignorowany przez Git. Zaznaczone `Use Gradle Build` jest konieczne dla natywnych reklam. Nie trzeba kompilować silnika ani bibliotek C++/NDK: używamy oficjalnych gotowych bibliotek ARM64.

Presety w `export_presets.cfg`:

- **Android APK** → podpisany debug APK do instalacji.
- **Android AAB** → debug AAB do testowania bundletool.
- **Android AAB unsigned** → release AAB bez podpisu; wymaga podpisania własnym kluczem przed uploadem.

Buduj z katalogu projektu poleceniami z README. Przy własnym wydaniu skopiuj preset release, włącz `package/signed`, ustaw keystore bez dodawania go ani hasła do Git. Godot obsługuje `GODOT_ANDROID_KEYSTORE_RELEASE_PATH`, `GODOT_ANDROID_KEYSTORE_RELEASE_USER`, `GODOT_ANDROID_KEYSTORE_RELEASE_PASSWORD`; dostarczaj je lokalnie lub przez bezpieczny system CI. Nie stosuj klucza debugowego jako upload key.

Min SDK 24, ARM64, tryb pionowy, OpenGL ES 3.0 Compatibility. Uprawnienia: Internet, stan sieci, wibracje; dodatkowe uprawnienia zadeklarowane przez SDK trzeba ocenić w scalonym manifeście. `allowBackup=false`. Nie ma kont ani serwerów gry.

## Reklamy

W repozytorium znajdują się źródła GDScript i Kotlin integracji **Poing Studios 5.1.0**, commit `615974e9f66921a54e3c71c33db0856bdbf19d13`, oraz jej oficjalne AAR dla Godot 4.6.3. Integracja używa Google Next-Gen Mobile Ads `ads-mobile-sdk:1.4.0`. Zależności Google/AndroidX pobiera Gradle. To nie jest atrapa reklam.

Włączony jest własny mały plugin eksportu `addons/neon_ads/`, który korzysta z niezmodyfikowanego eksportera Poing, bez pobierania iOS ani uruchamiania edytorowych mocków. Kod aplikacji sprawdza natywne singletony Android i nie ładuje adaptera SDK na desktopie.

Testowe identyfikatory Google:

- Application ID: `ca-app-pub-3940256099942544~3347511713` w `assets/app_config.json` (eksporter przekazuje do manifestu).
- Rewarded: `ca-app-pub-3940256099942544/5224354917`.
- Interstitial: `ca-app-pub-3940256099942544/1033173712`.
- Wszystkie trzy są w `assets/app_config.json`. Adapter odczytuje je z jednej konfiguracji.

Przed produkcją zastąp je własnymi identyfikatorami. Nie są to hasła. Skonfiguruj **Privacy & messaging / European regulations** w panelu AdMob, domenę polityki, dostawców i grupę wiekową. Produkcja wymaga wyboru 16+ lub 18+ zgodnego z rzeczywistymi odbiorcami. Nieustawiona grupa w testach uruchamia zachowawcze ustawienia prywatności. Nie jest to implementacja dla dzieci lub mieszanych grup wiekowych.

Aktualizacja UMP odbywa się przed inicjalizacją Ads. Jeżeli wymagana jest zgoda, ładowany i wyświetlany jest natywny formularz. Błąd powoduje brak reklam; gra pozostaje dostępna. Zmiana preferencji usuwa wcześniej załadowane reklamy. Rewarded przekazuje nagrodę tylko w rzeczywistym zdarzeniu `on_user_earned_reward`, z ochroną przed podwójnym wywołaniem. Interstitial tylko przy ponownym rozpoczęciu po wyniku, co trzeci raz i nie częściej niż co 180 sekund. Żaden format nie jest wyświetlany podczas przeciągania.

Przyszły Billing: `Store.data.ad_free` jest lokalnym stanem uprawnienia sprawdzanym przed interstitial. Nie ma przycisku ani fikcyjnego zakupu. Implementując Billing, ustawiaj to pole dopiero po sprawdzonym zakupie i dodaj odtwarzanie zakupów; sam zapis lokalny nie jest weryfikacją transakcji.

## Przed Google Play — rzeczywiste ograniczenia

**To nie jest deklaracja bieżącej zgodności ani akceptacji sklepu.** 2 listopada 2026 r. próba dostępu do aktualnej strony wymagań docelowego API zakończyła się HTTP 403 w polityce sieci środowiska. Sprawdź aktualne wymagania bezpośrednio w Play Console oraz na oficjalnych stronach:

- https://support.google.com/googleplay/android-developer/answer/11926878 — docelowy poziom API.
- https://developer.android.com/guide/practices/page-sizes — rozmiar stron pamięci 16 KB.
- https://support.google.com/googleplay/android-developer/answer/10787469 — Bezpieczeństwo danych.
- https://developers.google.com/admob/android/privacy — zgody i UMP.

Target 36 jest faktyczną konfiguracją projektu; sam target nie potwierdza pozostałych zasad. Przed wysyłką:

1. Wybierz ostateczny unikalny package ID (obecnie `com.neonblockmaster.puzzle`) i zwiększ version code przy kolejnych wydaniach.
2. Podpisz AAB własnym upload key i skonfiguruj Play App Signing.
3. Sprawdź wymóg target API, 64-bit, 16 KB (także wszystkie natywne biblioteki SDK), ostrzeżenia Android Vitals i raport testów wstępnych na bieżącym Play Console.
4. Uzupełnij wydawcę i kontakt w `store/privacy.html`; opublikuj pod publicznym HTTPS i wpisz URL w Play oraz UMP.
5. Ustaw produkcyjne AdMob ID, wiadomości zgód, grupę wiekową i deklarację reklam. Wypełnij Data safety zgodnie z faktycznie dołączonym SDK — nie zaznaczaj „brak zbierania danych” dla wersji z AdMob bez analizy dokumentacji Google.
6. Uzupełnij IARC/content rating, dostępność krajów, nazwę wydawcy oraz kontakt sklepu. Opisy i grafiki są w `store/`.
7. Wykonaj testy na urządzeniach według `TESTING.md`, w tym UMP w EOG, brak sieci, reklamy nagradzane i 16 KB. W razie obowiązku przeprowadź wymagane testy zamknięte dla konta deweloperskiego.

Gra nie zawiera płatności. Waluta jest wirtualna, offline, bez wymiany pieniężnej. Lokalny zegar i zapis nie są mechanizmem anty-cheat ani ochroną kryptograficzną.
