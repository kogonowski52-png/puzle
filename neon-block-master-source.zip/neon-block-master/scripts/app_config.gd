extends Node
## Public configuration only. Never place upload-key passwords here.
const PATH := "res://assets/app_config.json"
var data: Dictionary = {}
func _ready() -> void:
	var parsed = JSON.parse_string(FileAccess.get_file_as_string(PATH))
	if parsed is Dictionary: data = parsed
func production() -> bool:
	return data.get("mode","test") == "production"
func ad_id(kind: String) -> String:
	return str(data.get("admob",{}).get(kind+"_id",""))
func audience_configured() -> bool:
	return data.get("audience","") in ["16+","18+"]
func ads_allowed() -> bool:
	if OS.has_feature("production") and not production(): return false
	if not production(): return true
	if not audience_configured(): return false
	for key in ["app","rewarded","interstitial"]:
		var value := ad_id(key)
		if value.is_empty() or value.contains("3940256099942544"): return false
	return true
