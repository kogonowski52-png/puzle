extends Node
## Public configuration only. No exact birth date or identity is collected.
const PATH := "res://assets/app_config.json"
var data: Dictionary = {}
func _ready() -> void:
	var parsed = JSON.parse_string(FileAccess.get_file_as_string(PATH))
	if parsed is Dictionary: data = parsed
func production() -> bool:
	return data.get("mode","test") == "production"
func ad_id(kind: String) -> String:
	return str(data.get("admob",{}).get(kind+"_id",""))
func audience_configured() -> bool:
	return data.get("audience","") in ["16+","18+"]
func advertising_enabled() -> bool:
	# Families SDK suitability has not been verified. Mixed-audience packages
	# exclude the native advertising SDK entirely, including for adult players.
	return data.get("ads_enabled",false) == true and audience_configured()
func age_choice_required() -> bool:
	return advertising_enabled() and not Store.data.get("age_choice_made",false)
func ads_allowed() -> bool:
	if not advertising_enabled(): return false
	if not Store.data.get("age_choice_made",false): return false
	if not Store.data.get("age_band","unknown") in ["16_17","18_plus"]: return false
	if OS.has_feature("production") and not production(): return false
	if not production(): return true
	for key in ["app","rewarded","interstitial"]:
		var value := ad_id(key)
		if value.is_empty() or value.contains("3940256099942544"): return false
	return true
