@tool
extends EditorPlugin
var android_exporter = preload("res://addons/admob/internal/exporters/android/export_plugin.gd").new()
var settings_exporter = preload("res://addons/admob/internal/exporters/main_export_plugin.gd").new()
var registered := false
func _enter_tree() -> void:
	var config = JSON.parse_string(FileAccess.get_file_as_string("res://assets/app_config.json"))
	var enabled := false
	if config is Dictionary:
		enabled = config.get("ads_enabled",false) == true and config.get("audience","") in ["16+","18+"]
		ProjectSettings.set_setting("admob/general/android/app_id",config.get("admob",{}).get("app_id",""))
	ProjectSettings.set_setting("admob/general/android/enabled",enabled)
	if enabled:
		add_export_plugin(android_exporter)
		add_export_plugin(settings_exporter)
		registered = true
func _exit_tree() -> void:
	if registered:
		remove_export_plugin(android_exporter)
		remove_export_plugin(settings_exporter)
