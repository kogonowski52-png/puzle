extends SceneTree
const Board = preload("res://scripts/board.gd")
var checks := 0
var failures := 0

class NativeInitializationProbe extends RefCounted:
	signal on_initialization_complete(status: Dictionary)
	var completed := false
	var calls: Array[String] = []
	func set_request_configuration(_config, _devices): calls.append("configuration")
	func initialize(): calls.append("initialize")
	func set_app_muted(_muted): calls.append("mute" if completed else "INVALID_PREINIT_MUTE")

func check(condition: bool, message: String) -> void:
	checks += 1
	if not condition:
		failures += 1
		printerr("FAIL: "+message)

func hand(shape: Array, color := 1) -> Array:
	return [{"shape":shape,"color":color},{},{}]

func _initialize() -> void:
	call_deferred("run")

func run() -> void:
	await process_frame
	var b := Board.new()
	b.begin("classic")
	check(b.cells.size()==64 and b.hand.size()==3,"new board dimensions")
	check(b.can_place([[0,0]],Vector2i(7,7)),"last cell valid")
	check(not b.can_place([[0,0],[1,0]],Vector2i(7,7)),"right boundary")
	check(not b.can_place([[0,0]],Vector2i(-1,0)),"negative boundary")
	b.cells[0]=1
	check(not b.can_place([[0,0]],Vector2i.ZERO),"occupied cell")
	b.hand=hand([[0,0]])
	var before := b.snapshot()
	check(b.place(0,Vector2i.ZERO).is_empty(),"collision is rejected")
	check(b.snapshot()==before,"rejected move is side-effect free")
	check(b.place(-1,Vector2i.ONE).is_empty(),"invalid hand index")
	b=Board.new()
	b.mode="time"
	for i in range(1,8):
		b.cells[i]=2
		b.cells[i*8]=3
	b.hand=hand([[0,0]])
	var result := b.place(0,Vector2i.ZERO)
	check(result.lines==2 and result.cleared.size()==15,"row and column clear simultaneously with unique intersection")
	check(b.cells.all(func(v): return v==0),"simultaneous clear empties board")
	check(b.score==285 and b.combo==1,"multi-line scoring")
	check(b.remaining==186,"time combo bonus")
	for i in range(1,8): b.cells[i]=1
	b.hand=hand([[0,0]])
	result=b.place(0,Vector2i.ZERO)
	check(result.points==160 and b.combo==2,"successive clearing move combo")
	b.hand=hand([[0,0]])
	result=b.place(0,Vector2i.ZERO)
	check(b.combo==0 and result.points==10,"non-clearing move resets combo")
	b.cells.fill(1)
	b.cells[0]=0
	b.hand=hand([[0,0],[1,0]])
	check(not b.has_moves(),"no placement ends game")
	b.hand=hand([[0,0]])
	check(b.has_moves(),"last available single-cell placement found")
	b.cells.fill(1)
	b.deal()
	check(not b.has_moves(),"full board cannot be rescued by dealing")
	b.cells[0]=0
	for i in 30:
		b.deal()
		check(b.has_moves(),"refill guarantees one fitting piece when possible")
	var a := Board.new()
	var c := Board.new()
	a.begin("daily","2026-11-02")
	c.begin("daily","2026-11-02")
	check(a.hand==c.hand and a.target==c.target,"daily seed reproducibility")
	for i in 20:
		a.deal()
		c.deal()
		check(a.hand==c.hand,"daily sequence reproducibility")
	var restored := Board.restore(JSON.parse_string(JSON.stringify(a.snapshot())))
	check(restored!=null,"JSON snapshot restore")
	a.deal()
	restored.deal()
	check(a.hand==restored.hand,"RNG state survives save losslessly")
	var broken := a.snapshot()
	broken.cells=[1]
	check(Board.restore(broken)==null,"malformed cells rejected")
	broken=a.snapshot()
	broken.hand[0].shape=[[0,0],[0,0]]
	check(Board.restore(broken)==null,"duplicate shape squares rejected")
	broken=a.snapshot()
	broken.hand[0].shape=[[1.5,0]]
	check(Board.restore(broken)==null,"fractional shape coordinates rejected")
	check(not a.revive(),"daily cannot revive")
	b=Board.new()
	b.begin("classic")
	b.cells.fill(1)
	b.ended=true
	check(b.revive() and not b.ended and b.has_moves(),"earned continue clears space")
	check(not b.revive(),"continue once per run")
	b=Board.new()
	b.begin("time")
	b.remaining=0
	check(not b.revive(),"expired timer cannot revive")
	# Many real games: legal placements preserve board and score invariants.
	var games := 0
	var moves := 0
	var started := Time.get_ticks_msec()
	for seed_value in 60:
		b=Board.new()
		b.rng.seed=seed_value
		b.deal()
		for step in 180:
			var chosen := -1
			var at := Vector2i.ZERO
			for i in 3:
				if b.hand[i].is_empty(): continue
				for y in 8:
					for x in 8:
						if chosen<0 and b.can_place(b.hand[i].shape,Vector2i(x,y)):
							chosen=i
							at=Vector2i(x,y)
			if chosen<0:
				check(not b.has_moves(),"game-over search agrees with placements")
				break
			var old_score := b.score
			result=b.place(chosen,at)
			check(not result.is_empty() and b.score>old_score,"valid simulation move scores")
			check(Board.restore(JSON.parse_string(JSON.stringify(b.snapshot())))!=null,"all simulated saves restore")
			moves+=1
		games+=1
	print("SIMULATION: ",games," games / ",moves," moves / ",Time.get_ticks_msec()-started," ms")
	check(root.get_node("Sound").music.stream.loop_mode==AudioStreamWAV.LOOP_FORWARD,"background music loops")
	var store := root.get_node("Store")
	store.data=store.defaults()
	store.data.coins=120
	check(store.save(),"atomic initial save")
	check(store.purchase("aurora",120),"theme purchase")
	check(store.data.coins==0 and store.data.theme=="aurora","purchase deducts exact price and selects")
	check(not store.purchase("sunset",180),"insufficient funds")
	check(store.purchase("aurora",120) and store.data.coins==0,"owned theme costs nothing")
	store.data.login=""
	check(store.login_reward()==15 and store.login_reward()==0,"daily login claimed once")
	check(store.daily_reward("2026-11-02")==80 and store.daily_reward("2026-11-02")==0,"daily completion claimed once")
	store.save()
	store.save()
	var expected: Dictionary = store.data.duplicate(true)
	var f := FileAccess.open("user://progress.json",FileAccess.WRITE)
	f.store_string("{broken"); f.close()
	store.load_data()
	check(store.data==JSON.parse_string(JSON.stringify(expected)),"corrupt primary recovers valid backup")
	store.data=store.defaults()
	store.save()
	check(load("res://scripts/admob_adapter.gd").can_instantiate(),"AdMob adapter compiles against pinned SDK")
	var ads := root.get_node("Ads")
	var coins: int = store.data.coins
	check(not ads.reward_available(),"desktop never simulates ads")
	check(not ads.reward(func(): store.data.coins+=25),"unavailable rewarded ad rejects request")
	check(store.data.coins==coins,"no SDK means no unearned coins")
	# Old saves migrate without losing earned progress or purchased themes.
	var legacy: Dictionary = store.defaults()
	legacy.erase("lab_charges")
	legacy.erase("result_bonus")
	legacy.coins = 321
	legacy.themes.append("aurora")
	legacy.theme = "aurora"
	f = FileAccess.open("user://progress.json",FileAccess.WRITE)
	f.store_string(JSON.stringify(legacy)); f.close()
	store.load_data()
	check(store.data.coins==321 and store.data.theme=="aurora","v1 save preserves currency and theme")
	check(store.data.lab_charges==0 and store.data.result_bonus.is_empty(),"v1 save receives new reward fields")
	store.data=store.defaults()
	check(store.add_plasma_charge() and store.data.lab_charges==1,"earned charge persists first step")
	store.load_data()
	check(store.data.lab_charges==1 and not "plasma" in store.data.themes,"partial lab progress survives restart")
	check(store.add_plasma_charge() and not "plasma" in store.data.themes,"two ads do not prematurely unlock theme")
	check(store.add_plasma_charge() and store.data.theme=="plasma","third earned charge unlocks and selects PLASMA")
	check(not store.add_plasma_charge() and store.data.lab_charges==3,"owned reward cannot be granted again")
	store.data=store.defaults()
	store.data.coins=240
	check(store.purchase("plasma",240) and store.data.coins==0,"PLASMA can be earned entirely without ads")
	check(not store.purchase("invented",-100) and store.data.coins==0,"invalid catalog entry cannot mint currency")
	store.data=store.defaults()
	store.data.coins=10
	store.prepare_result_bonus(90)
	var bonus_id: String = store.data.result_bonus.id
	check(not store.claim_result_bonus("wrong-run") and store.data.coins==10,"stale rewarded callback cannot claim another run")
	check(store.claim_result_bonus(bonus_id) and store.data.coins==100,"double reward adds the exact run award once")
	check(not store.claim_result_bonus(bonus_id) and store.data.coins==100,"duplicate reward event does not pay twice")
	store.load_data()
	check(not store.claim_result_bonus(bonus_id) and store.data.coins==100,"bonus claim persists across restart")
	store.prepare_result_bonus(10)
	check(store.data.result_bonus.id!=bonus_id and not store.claim_result_bonus(bonus_id),"new result replaces the old bonus identity")
	store.prepare_result_bonus(0)
	check(store.data.result_bonus.is_empty(),"zero-earned run offers no misleading double reward")
	var invalid_profile: Dictionary = store.defaults()
	invalid_profile.lab_charges=1.5
	check(not store.validate(invalid_profile),"fractional lab progress is rejected")
	var config := root.get_node("AppConfig")
	var original_config: Dictionary = config.data.duplicate(true)
	config.data.mode="production"
	check(not config.ads_allowed(),"production with unset audience cannot load ads")
	config.data.audience="16+"
	check(not config.ads_allowed(),"production refuses Google test ad IDs")
	config.data=original_config
	store.data=store.defaults()
	store.save()

	# Everyone, including unknown/young ages, gets the same restrictive profile.
	var family_config: Dictionary = config.data.duplicate(true)
	check(config.advertising_enabled() and config.child_profile(),"classic family ad integration enabled")
	for band in ["unknown","under_13","13_15","16_17","18_plus"]:
		store.set_age_band(band)
		check(config.ads_allowed(),"test ad eligibility is independent of declared age: "+band)
	check(not config.age_choice_required(),"uniform child-directed profile does not collect an unnecessary age")
	config.data.ad_sdk="nextgen_unreviewed"
	check(not config.advertising_enabled(),"unselected SDK cannot be activated accidentally")
	config.data=family_config
	var adapter = load("res://scripts/admob_adapter.gd").new()
	var sdk_request: Dictionary = adapter.restricted_configuration().convert_to_dictionary()
	check(sdk_request.tag_for_child_directed_treatment==1,"SDK payload enables child-directed treatment")
	check(sdk_request.tag_for_under_age_of_consent==1,"SDK payload enables under-age treatment")
	check(sdk_request.max_ad_content_rating=="G","SDK payload limits creatives to G rating")
	check(adapter.restricted_request().convert_to_dictionary().extras.get("npa")=="1","every ad request explicitly disables personalisation")
	adapter.free()
	# Classic GMA's setAppMuted throws before initialize completes. Exercise the
	# actual adapter with a contract probe; this does not simulate impressions.
	var previous_bridge = MobileAds._plugin
	var previous_listener = MobileAds._current_on_initialization_complete_listener
	var bridge := NativeInitializationProbe.new()
	var startup = load("res://tests/initialization_adapter_probe.gd").new()
	MobileAds._plugin = bridge
	startup._enable_restricted_ads()
	check(bridge.calls==["configuration","initialize"],"startup configures privacy before init without calling pre-init mute")
	check(startup.loads==0 and not startup.initialized,"no loads before SDK initialization callback")
	bridge.completed = true
	startup.initialization_listener.on_initialization_complete.call(null)
	check(bridge.calls==["configuration","initialize","mute"],"mute is applied only after SDK initialization")
	check(startup.loads==2 and startup.initialized,"both formats load after successful initialization")
	MobileAds._plugin = previous_bridge
	MobileAds._current_on_initialization_complete_listener = previous_listener
	startup.free()
	store.data=store.defaults()
	store.save()

	# Real scene, all screens, both languages and mouse/touch drag paths.
	var main = load("res://scenes/main.tscn").instantiate()
	root.add_child(main)
	await create_timer(1.5).timeout
	check(main.screen=="menu" and not store.data.age_choice_made,"restricted ad startup skips unnecessary age collection")
	main.age_screen()
	var age_buttons: Array = main.ui.get_children().filter(func(n): return n is Button)
	check(age_buttons.size()==5 and age_buttons.all(func(n): return n.get_theme_stylebox("normal").bg_color==age_buttons[0].get_theme_stylebox("normal").bg_color),"neutral age choices use equal styling")
	check(age_buttons.all(func(n): return not "ad" in n.text.to_lower() and not "reward" in n.text.to_lower()),"age screen does not promise advertising benefits for older ages")
	for lang in ["pl","en"]:
		store.data.settings.language=lang
		for method in ["menu","modes","daily_screen","stats","shop","settings","info","licenses","lab","age_screen"]:
			main.call(method)
			await process_frame
			check(main.ui.get_child_count()>0,"functional screen "+lang+" / "+method)
	main.new_game("classic")
	main.model.hand=hand([[0,0]])
	await process_frame
	var press := InputEventScreenTouch.new()
	press.index=0
	press.pressed=true
	press.position=main.stage.get_global_transform()*Vector2(146,1095)
	main._input(press)
	check(main.view.drag==0,"touch picks piece from generous tray hitbox")
	var drag := InputEventScreenDrag.new()
	drag.index=0
	drag.position=main.stage.get_global_transform()*Vector2(94,482)
	main._input(drag)
	check(main.view.anchor==Vector2i.ZERO,"touch preview accounts for finger offset")
	press.pressed=false
	press.position=drag.position
	main._input(press)
	check(main.model.cells[0]>0 and main.model.score==10,"touch release places piece")
	main.model.hand=hand([[0,0]])
	var mouse := InputEventMouseButton.new()
	mouse.button_index=MOUSE_BUTTON_LEFT
	mouse.pressed=true
	mouse.position=main.stage.get_global_transform()*Vector2(146,1095)
	main._input(mouse)
	mouse.pressed=false
	mouse.position=main.stage.get_global_transform()*Vector2(170,482)
	main._input(mouse)
	check(main.model.cells[1]>0 and main.model.score==20,"mouse drag places piece")
	main.new_game("time")
	main._process(1.0)
	check(main.model.remaining<180,"active time decreases")
	main.pause_game()
	var paused: float = main.model.remaining
	main._process(2.0)
	check(main.model.remaining==paused,"pause freezes timer")
	main.game_screen()
	main._notification(Node.NOTIFICATION_APPLICATION_PAUSED)
	check(main.screen=="pause","background pauses and saves")
	main.game_screen()
	main.model.remaining=.1
	main._process(.2)
	check(main.screen=="result" and main.model.ended,"timer expiry displays real result screen")
	main.new_game("daily")
	main.model.score=main.model.target
	main.finish(true)
	check(store.data.daily.get(main.model.day,false),"daily success recorded")
	var shown_bonus: Dictionary = store.data.result_bonus
	if not shown_bonus.is_empty():
		store.claim_result_bonus(shown_bonus.id)
		main.result_screen()
		check(main.ui.get_children().any(func(n): return n is Button and n.text=="Reward doubled ✓" and n.disabled),"earned bonus UI confirms claimed reward without a second ad")
	store.data.coins=240
	store.purchase("plasma",240)
	main.lab()
	check(main.ui.get_children().any(func(n): return n is Label and n.text=="PLASMA UNLOCKED ✓"),"owned PLASMA UI has no misleading remaining-ad requirement")
	main.queue_free()
	await create_timer(8.15).timeout
	check(root.get_node("Sound").music.playing,"music plays beyond the full eight-second loop")
	root.get_node("Sound").shutdown()
	await create_timer(.15).timeout
	print("CHECKS: ",checks,"; PASSED: ",checks-failures,"; FAILED: ",failures)
	quit(0 if failures==0 else 1)
