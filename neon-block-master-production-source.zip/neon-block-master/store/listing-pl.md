# Neon Block Master – Puzzle

Krótki opis (do 80 znaków):
Neonowe klocki, trzy tryby i codzienne wyzwania. Znajdź swój rytm!

## Pełny opis

Utknąłeś? Młotek usuwa wybrany obszar 3×3, a Zmiana daje świeży zestaw figur bez kasowania planszy. Pakiet startowy gratis. Jedna dobrowolna reklama daje 1 Młotek i 2 Zmiany; taki sam pakiet kupisz za 90 monet zdobytych w grze. Pomocniki działają w Classic i Time Attack. W Daily wszyscy grają bez pomocników.

Wejdź w neonowy rytm! Przeciągaj figury na planszę 8 × 8, wypełniaj rzędy i kolumny, a potem połącz kolejne trafienia w satysfakcjonujące combo.

Wybierz swój sposób gry:
• Classic — spokojna rozgrywka bez limitu czasu i walka o własny rekord.
• Time Attack — trzy minuty na wynik; usuwaj wiele linii, aby zyskać cenne sekundy.
• Daily Challenge — nowe zadanie każdego dnia i kalendarz Twoich sukcesów.

Zdobywaj Neon Coins za wyzwania, codzienne uruchomienie gry i nowe rekordy. Odblokuj motywy Aurora i Sunset oraz efekt Orbit. W NEON LAB odblokuj PLASMA za trzy dobrowolnie obejrzane reklamy z nagrodą albo 240 monet zdobytych w grze; postęp nie wygasa. Wybierasz konkretną nagrodę — bez losowania.

Ciesz się oryginalną elektroniczną muzyką, świetlnymi efektami i czytelnym podglądem ruchu. Wyłącz dźwięki lub wibracje, gdy potrzebujesz ciszy. Interfejs dostępny po polsku i angielsku.

Gra działa offline i automatycznie zapisuje Twój postęp na urządzeniu. Zawiera reklamy z nagrodą oraz ograniczone reklamy między rozgrywkami; reklamy wymagają internetu. Bez zakupów w aplikacji.

Bez konta. Bez serwera gry. Po prostu Twoja plansza i kolejny dobry ruch.


Nota wydawnicza (nie do opisu sklepu): szkic dla wersji z reklamami. APK 1.4.0 ma oficjalne jednostki testowe Google i nie zarabia. Przed wydaniem produkcyjnym wymagane są testy telefonu, aktualna weryfikacja Families SDK, polityka pod publicznym URL, deklaracje Play i podpis. Gra jest przeznaczona dla dzieci od 3 lat i dorosłych; ocenę treści ustala IARC.
