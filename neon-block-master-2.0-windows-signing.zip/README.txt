NEON BLOCK MASTER 2.0.0 — AKTUALIZACJA GRY Z GOOGLE PLAY

1. Rozpakuj CALY ZIP do folderu na komputerze Windows.
2. Uruchom podpisz.cmd. Ten plik odblokowuje tylko towarzyszacy podpisz.ps1;
   nie zmienia globalnej polityki PowerShell.
3. Skrypt uzyje ISTNIEJACEGO pliku:
   C:\Users\PC\NeonBlockMaster-Signing\neon-upload.p12
   Wpisz dotychczasowe haslo. Nie tworz nowego klucza.
4. Oczekiwany certyfikat upload SHA-256:
   813efb0ae5ebf0cba2c270a7492d623a94053b46417bc00053c541c567fee467
5. Po napisie PODPIS POTWIERDZONY wyslij do TESTOW WEWNETRZNYCH tej samej gry:
   wynik\neon-block-master-2.0.0-play-signed.aab
   Nie wysylaj pliku z unsigned w nazwie.

Pakiet: com.neonblockmaster.puzzle
Wersja: 2.0.0, versionCode 12 (wiekszy niz znane 1.5.0/code10 i lokalny szkic11).
Podpisywanie niczego nie publikuje. Nie odinstalowuj gry z Play przed aktualizacja.
Klucz i haslo zostaja u Ciebie. Zrob ich prywatna kopie poza folderem paczki.
Sam podpis nie potwierdza reklam, platnosci ani zatwierdzenia Google Play.

Szczegoly testow i jedna instrukcja sprawdzenia reklamy na telefonie: UPDATE-2.0.md.
Gotowy APK testowy pobiera sie oddzielnie; instaluje sie obok Play i nie zarabia.
W tej paczce sa AAB, publiczna konfiguracja i skrypty. Nie ma prywatnego klucza ani hasla.
