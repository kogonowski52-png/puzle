@tool
extends EditorPlugin
var android_exporter = preload("res://addons/admob/internal/exporters/android/export_plugin.gd").new()
var settings_exporter = preload("res://addons/admob/internal/exporters/main_export_plugin.gd").new()
func _enter_tree() -> void:
	var config = JSON.parse_string(FileAccess.get_file_as_string("res://assets/app_config.json"))
	if config is Dictionary:
		ProjectSettings.set_setting("admob/general/android/app_id",config.get("admob",{}).get("app_id",""))
	add_export_plugin(android_exporter)
	add_export_plugin(settings_exporter)
func _exit_tree() -> void:
	remove_export_plugin(android_exporter)
	remove_export_plugin(settings_exporter)
