extends Node
## Classic Google Mobile Ads 24.9.0 / Poing 4.3.1. No mocked impressions.
signal changed
signal visibility(active: bool)
var rewarded: RewardedAd
var interstitial: InterstitialAd
var initialized := false
var consent_ready := false
var consent_busy := false
var generation := 0
var reward_loading := false
var interstitial_loading := false
var retry_reward_at := 0.0
var retry_interstitial_at := 0.0
var retry_consent_at := 0.0
var reward_failures := 0
var interstitial_failures := 0
var consent_failures := 0
var reward_loaded_at := 0.0
var interstitial_loaded_at := 0.0
var initialization_listener := OnInitializationCompleteListener.new()

func now() -> float:
	return Time.get_ticks_msec()/1000.0

func initialize() -> void:
	if consent_busy or not AppConfig.ads_allowed(): return
	if not Engine.has_singleton("PoingGodotAdMobConsentInformation"): return
	consent_busy = true
	retry_consent_at = 0
	# Demo units are for testing SDK delivery on the owner's device, not revenue.
	if not AppConfig.production():
		consent_busy = false
		_enable_restricted_ads()
		return
	var params := ConsentRequestParameters.new()
	params.tag_for_under_age_of_consent = true
	UserMessagingPlatform.consent_information.update(params,_consent_updated,func(_error):
		consent_busy = false
		consent_failures += 1
		retry_consent_at = now()+minf(300,60*pow(2,mini(3,consent_failures-1)))
		changed.emit())

func _consent_updated() -> void:
	consent_busy = false
	consent_failures = 0
	var status := UserMessagingPlatform.consent_information.get_consent_status()
	# Never show an adult consent form to a young child. Production fails closed
	# if UMP indicates any unresolved consent requirement.
	if status in [ConsentInformation.ConsentStatus.NOT_REQUIRED,ConsentInformation.ConsentStatus.OBTAINED]:
		_enable_restricted_ads()
	else: changed.emit()

func _enable_restricted_ads() -> void:
	consent_ready = true
	var request := restricted_configuration()
	MobileAds.set_request_configuration(request)
	MobileAds.set_app_muted(not Store.data.settings.sound)
	if initialized:
		load_rewarded()
		load_interstitial()
		return
	initialization_listener.on_initialization_complete = func(_status):
		initialized = true
		if consent_ready:
			load_rewarded()
			load_interstitial()
	MobileAds.initialize(initialization_listener)

func restricted_configuration() -> RequestConfiguration:
	var request := RequestConfiguration.new()
	request.max_ad_content_rating = RequestConfiguration.MAX_AD_CONTENT_RATING_G
	request.tag_for_child_directed_treatment = RequestConfiguration.TagForChildDirectedTreatment.TRUE
	request.tag_for_under_age_of_consent = RequestConfiguration.TagForUnderAgeOfConsent.TRUE
	return request

func restricted_request() -> AdRequest:
	var request := AdRequest.new()
	request.extras = {"npa":"1"}
	return request

func load_rewarded() -> void:
	if not consent_ready or reward_loading or rewarded != null: return
	reward_loading = true
	var epoch := generation
	var callback := RewardedAdLoadCallback.new()
	callback.on_ad_failed_to_load = func(_error):
		if epoch != generation: return
		reward_loading = false
		reward_failures += 1
		retry_reward_at = now()+minf(300,15*pow(2,mini(5,reward_failures-1)))
		changed.emit()
	callback.on_ad_loaded = func(ad):
		if epoch != generation or not consent_ready:
			ad.destroy()
			return
		reward_loading = false
		reward_failures = 0
		retry_reward_at = 0
		rewarded = ad
		reward_loaded_at = now()
		changed.emit()
	RewardedAdLoader.new().load(AppConfig.ad_id("rewarded"),restricted_request(),callback)

func load_interstitial() -> void:
	if not consent_ready or interstitial_loading or interstitial != null: return
	interstitial_loading = true
	var epoch := generation
	var callback := InterstitialAdLoadCallback.new()
	callback.on_ad_failed_to_load = func(_error):
		if epoch != generation: return
		interstitial_loading = false
		interstitial_failures += 1
		retry_interstitial_at = now()+minf(300,15*pow(2,mini(5,interstitial_failures-1)))
		changed.emit()
	callback.on_ad_loaded = func(ad):
		if epoch != generation or not consent_ready:
			ad.destroy()
			return
		interstitial_loading = false
		interstitial_failures = 0
		retry_interstitial_at = 0
		interstitial = ad
		interstitial_loaded_at = now()
		changed.emit()
	InterstitialAdLoader.new().load(AppConfig.ad_id("interstitial"),restricted_request(),callback)

func show_reward(callback: Callable) -> void:
	if rewarded == null or not consent_ready: return
	MobileAds.set_app_muted(not Store.data.settings.sound)
	var ad := rewarded
	rewarded = null
	var state := {"earned":false,"closed":false}
	var full := FullScreenContentCallback.new()
	var cleanup := func():
		if state.closed: return
		state.closed = true
		ad.full_screen_content_callback = FullScreenContentCallback.new()
		ad.destroy()
		visibility.emit(false)
		load_rewarded()
	full.on_ad_dismissed_full_screen_content = cleanup
	full.on_ad_failed_to_show_full_screen_content = func(_error): cleanup.call()
	ad.full_screen_content_callback = full
	var earned := OnUserEarnedRewardListener.new()
	earned.on_user_earned_reward = func(_item):
		if state.earned: return
		state.earned = true
		if callback.is_valid(): callback.call()
	visibility.emit(true)
	ad.show(earned)
	changed.emit()

func show_interstitial() -> void:
	if interstitial == null or not consent_ready: return
	MobileAds.set_app_muted(not Store.data.settings.sound)
	var ad := interstitial
	interstitial = null
	var state := {"closed":false}
	var full := FullScreenContentCallback.new()
	var cleanup := func():
		if state.closed: return
		state.closed = true
		ad.full_screen_content_callback = FullScreenContentCallback.new()
		ad.destroy()
		visibility.emit(false)
		load_interstitial()
	full.on_ad_dismissed_full_screen_content = cleanup
	full.on_ad_failed_to_show_full_screen_content = func(_error): cleanup.call()
	ad.full_screen_content_callback = full
	visibility.emit(true)
	ad.show()

func privacy() -> void:
	# All audiences use the restrictive child-directed configuration. There is
	# no switch here to opt into personalised advertising or adult consent.
	pass

func _process(_delta: float) -> void:
	var time := now()
	if retry_consent_at > 0 and time >= retry_consent_at: initialize()
	if not consent_ready: return
	# Google ads expire after one hour. Refresh before that deadline.
	if rewarded != null and time-reward_loaded_at >= 3000:
		rewarded.destroy()
		rewarded = null
		retry_reward_at = time
		changed.emit()
	if interstitial != null and time-interstitial_loaded_at >= 3000:
		interstitial.destroy()
		interstitial = null
		retry_interstitial_at = time
	if retry_reward_at > 0 and time >= retry_reward_at:
		retry_reward_at = 0
		load_rewarded()
	if retry_interstitial_at > 0 and time >= retry_interstitial_at:
		retry_interstitial_at = 0
		load_interstitial()
