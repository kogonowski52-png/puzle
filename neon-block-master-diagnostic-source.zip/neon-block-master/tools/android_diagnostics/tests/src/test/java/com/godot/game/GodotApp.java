package com.godot.game; public class GodotApp extends android.app.Activity {}
