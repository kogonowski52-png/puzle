# SPDX-License-Identifier: MIT
# Copyright (c) 2026 Neon Block Master contributors.
@tool
extends EditorExportPlugin
func _get_name() -> String: return "NeonClassicGoogleAds"
func _supports_platform(platform: EditorExportPlatform) -> bool:
	return platform is EditorExportPlatformAndroid
func _get_android_libraries(_platform: EditorExportPlatform, debug: bool) -> PackedStringArray:
	var variant := "debug" if debug else "release"
	return PackedStringArray([
		"res://addons/admob/android/bin/ads/libs/poing-godot-admob-ads-"+variant+".aar",
		"res://addons/admob/android/bin/ads/libs/poing-godot-admob-core-"+variant+".aar"])
func _get_android_dependencies(_platform: EditorExportPlatform, _debug: bool) -> PackedStringArray:
	return PackedStringArray(["com.google.android.gms:play-services-ads:24.9.0","com.google.android.ump:user-messaging-platform:4.0.0","androidx.appcompat:appcompat:1.7.1","com.google.android.material:material:1.13.0"])
func _get_android_manifest_element_contents(_platform: EditorExportPlatform, _debug: bool) -> String:
	return """
<uses-permission xmlns:tools="http://schemas.android.com/tools" android:name="android.permission.AD_ID" tools:node="remove" />
<uses-permission xmlns:tools="http://schemas.android.com/tools" android:name="com.google.android.gms.permission.AD_ID" tools:node="remove" />
<uses-permission xmlns:tools="http://schemas.android.com/tools" android:name="android.permission.ACCESS_ADSERVICES_AD_ID" tools:node="remove" />
<uses-permission xmlns:tools="http://schemas.android.com/tools" android:name="android.permission.ACCESS_ADSERVICES_TOPICS" tools:node="remove" />
<uses-permission xmlns:tools="http://schemas.android.com/tools" android:name="android.permission.ACCESS_ADSERVICES_ATTRIBUTION" tools:node="remove" />
<uses-permission xmlns:tools="http://schemas.android.com/tools" android:name="android.permission.READ_PHONE_STATE" tools:node="remove" />
<uses-permission xmlns:tools="http://schemas.android.com/tools" android:name="android.permission.READ_BASIC_PHONE_STATE" tools:node="remove" />
"""
func _get_android_manifest_application_element_contents(_platform: EditorExportPlatform, _debug: bool) -> String:
	var config = JSON.parse_string(FileAccess.get_file_as_string("res://assets/app_config.json"))
	var app_id: String = config.admob.app_id
	return """
<meta-data android:name="com.google.android.gms.ads.APPLICATION_ID" android:value="%s" />
<meta-data android:name="com.google.android.gms.ads.DELAY_APP_MEASUREMENT_INIT" android:value="true" />
""" % app_id
