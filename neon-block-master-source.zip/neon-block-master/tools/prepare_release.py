#!/usr/bin/env python3
"""Validate public release settings; build only with the owner's upload key."""
import argparse, html, ipaddress, json, os, re, subprocess, sys, time
from pathlib import Path
from urllib.parse import urlsplit
ROOT=Path(__file__).resolve().parents[1]
TEST_PUBLISHER='3940256099942544'

def validate(config):
    errors=[]
    allowed={"mode","publisher_name","contact_email","privacy_url","website_url","audience","admob","ads_enabled"}
    if set(config)-allowed: errors.append("Unknown configuration fields rejected; never add passwords or signing credentials")
    if config.get('mode')!='production': errors.append('mode must be production')
    for key in ('publisher_name','contact_email','privacy_url','website_url'):
        if not isinstance(config.get(key),str) or not config[key].strip(): errors.append(f'{key}: required')
    email=config.get('contact_email','')
    if not isinstance(email,str) or not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+',email): errors.append('contact_email: valid public email required')
    for key in ('privacy_url','website_url'):
        try: u=urlsplit(config.get(key,''))
        except (ValueError,TypeError,AttributeError): errors.append(f'{key}: invalid URL');continue
        if u.scheme!='https' or not u.hostname or u.username or u.password or u.hostname in ('localhost','example.com','example.net','example.org') or u.hostname.endswith('.example.com'):
            errors.append(f'{key}: public HTTPS URL required')
        if u.hostname:
            try:
                if not ipaddress.ip_address(u.hostname).is_global: errors.append(f'{key}: private/local address rejected')
            except ValueError: pass
    enabled=config.get('ads_enabled',True)
    if not isinstance(enabled,bool): errors.append('ads_enabled must be a boolean')
    if config.get('audience') not in ('16+','18+','mixed','children'): errors.append('audience: choose the actual intended audience')
    if config.get('audience') in ('mixed','children') and enabled: errors.append('Families SDK review unavailable: advertising remains disabled for mixed/child audiences')
    ads=config.get('admob',{})
    if not isinstance(ads,dict): ads={}
    if set(ads)-{"app_id","rewarded_id","interstitial_id"}: errors.append("Unknown AdMob configuration fields rejected")
    if enabled:
        publishers=[]
        for name,sep in [('app_id','~'),('rewarded_id','/'),('interstitial_id','/')]:
            value=ads.get(name,'')
            match=re.fullmatch(r'ca-app-pub-(\d{16})'+re.escape(sep)+r'\d{10}',value) if isinstance(value,str) else None
            if not match or match[1]==TEST_PUBLISHER: errors.append(f'admob.{name}: production ID required (Google test IDs rejected)')
            else: publishers.append(match[1])
        if len(set(publishers))>1: errors.append('All AdMob IDs must belong to the same publisher')
        if ads.get('rewarded_id')==ads.get('interstitial_id'): errors.append('Rewarded and Interstitial must use separate ad units')
    return errors

def website(config,out):
    if not config.get('ads_enabled',True):
        return family_website(config,out)
    out.mkdir(parents=True,exist_ok=True)
    source=(ROOT/'store/privacy.html').read_text()
    publisher=html.escape(config['publisher_name']);email=html.escape(config['contact_email'])
    source=source.replace('[UZUPEŁNIJ NAZWĘ I ADRES]',publisher).replace('[UZUPEŁNIJ E-MAIL]',email).replace('[COMPLETE NAME, ADDRESS AND EMAIL BEFORE PUBLICATION]',publisher+' — '+email)
    source=source.replace('Dokument do uzupełnienia przed publikacją. ','').replace(' Opublikuj ten dokument pod publicznym adresem HTTPS i podaj go w Google Play oraz AdMob UMP.','')
    source=source.replace('Wersja deweloperska korzysta z identyfikatorów testowych.','').replace('Developer builds use test ad identifiers.','')
    source=source.replace('Wydawca musi przed publikacją określić grupę wiekową i skonfigurować odpowiednie flagi SDK oraz formularze UMP. Ten szablon nie stanowi deklaracji zgodności z zasadami Families ani przeznaczenia dla dzieci.',f'Gra przeznaczona jest dla odbiorców {html.escape(config["audience"])}. Nie jest kierowana do dzieci. Formularze zgód i dostawców reklam skonfigurowano w Google UMP; ich działanie należy zweryfikować na urządzeniu.')
    source=source.replace('The publisher must determine the target age group, appropriate SDK flags, lawful bases and consent messages before release, and keep the Play Data safety disclosure accurate.',f'The intended audience is {html.escape(config["audience"])}. This game is not directed at children. The publisher must keep consent configuration and the Play Data safety disclosure accurate.')
    # The generated text describes the chosen configuration; never certify legal or SDK compliance.
    source=source.replace('Formularze zgód i dostawców reklam skonfigurowano w Google UMP; ich działanie należy zweryfikować na urządzeniu.','Zgody obsługuje Google UMP zgodnie z ustawieniami wydawcy.')
    (out/'privacy.html').write_text(source)
    pub=config['admob']['app_id'].split('pub-')[1].split('~')[0]
    (out/'app-ads.txt').write_text(f'google.com, pub-{pub}, DIRECT, f08c47fec0942fa0\n')
    (out/'index.html').write_text(f'<!doctype html><html lang="pl"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Neon Block Master</title><body style="background:#080d1e;color:#eff3ff;font:20px system-ui;max-width:760px;margin:60px auto;padding:24px"><h1>Neon Block Master</h1><p>Classic · Time Attack · Daily Challenge</p><p>{publisher} · <a href="mailto:{email}">{email}</a></p><p><a href="privacy.html">Polityka prywatności / Privacy policy</a></p></body></html>')

def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config',type=Path,default=ROOT/'config/publishing.json')
    parser.add_argument('--stage-website',type=Path,help='Prepare static website files; does not host or publish them')
    parser.add_argument('--check',action='store_true')
    parser.add_argument('--build',action='store_true')
    parser.add_argument('--website',type=Path,help='Generate site and app-ads.txt in this directory after validation')
    args=parser.parse_args(argv)
    try: config=json.loads(args.config.read_text())
    except (OSError,ValueError):
        print('Missing/invalid config. Copy config/publishing.example.json to config/publishing.json and fill public data.',file=sys.stderr);return 2
    if not isinstance(config,dict): print('Config must be an object.',file=sys.stderr);return 2
    if args.stage_website:
        if not isinstance(config.get('publisher_name'),str) or not config['publisher_name'].strip() or not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+',config.get('contact_email','')):
            print('Public publisher name and valid contact email required.',file=sys.stderr);return 2
        if config.get('audience') in ('mixed','children') and config.get('ads_enabled',True):
            print('Families advertising is not enabled without verified SDK support.',file=sys.stderr);return 2
        website(config,args.stage_website)
        print('Static website prepared. Hosting and public URL are not verified.')
        if not args.build and not args.check: return 0
    errors=validate(config)
    if errors:
        print('Release blocked:\n'+'\n'.join('- '+e for e in errors),file=sys.stderr);return 2
    print('Public configuration: valid. This does not verify account ownership, HTTPS hosting, UMP setup or current Play policies.')
    if args.website: website(config,args.website)
    if not args.build: return 0
    required=['GODOT_ANDROID_KEYSTORE_RELEASE_PATH','GODOT_ANDROID_KEYSTORE_RELEASE_USER','GODOT_ANDROID_KEYSTORE_RELEASE_PASSWORD']
    missing=[key for key in required if not os.environ.get(key)]
    if missing: print('Signing unavailable; set securely: '+', '.join(missing),file=sys.stderr);return 2
    key=Path(os.environ[required[0]])
    if not key.is_file(): print('Upload keystore file is unavailable.',file=sys.stderr);return 2
    # Refuse the known test key. Check certificate fingerprint, never print passwords.
    password_env='GODOT_ANDROID_KEYSTORE_RELEASE_PASSWORD'
    result=subprocess.run(['keytool','-list','-v','-keystore',str(key),'-storepass:env',password_env,'-alias',os.environ[required[1]]],capture_output=True,text=True)
    if result.returncode or 'CN=Android Debug' in result.stdout:
        print('A valid non-debug upload key is required.',file=sys.stderr);return 2
    paths=[ROOT/'assets/app_config.json',ROOT/'project.godot',ROOT/'export_presets.cfg']
    backups={p:p.read_bytes() for p in paths}
    started=time.time()
    try:
        paths[0].write_text(json.dumps(config,indent=2,ensure_ascii=False)+'\n')
        preset=backups[paths[2]].decode()
        enabled='true' if config.get('ads_enabled',True) else 'false'
        preset=re.sub(r'permissions/(internet|access_network_state)=(true|false)',lambda m:'permissions/'+m[1]+'='+enabled,preset)
        paths[2].write_text(preset)
        subprocess.run(['godot','--headless','--path',str(ROOT),'--export-release','Android Production'],cwd=ROOT,check=True)
        artifact=ROOT/'builds/neon-block-master-production.aab'
        if not artifact.is_file() or artifact.stat().st_mtime<started: raise RuntimeError('No fresh AAB was created')
        import zipfile
        with zipfile.ZipFile(artifact) as z:
            if not any(n.startswith('META-INF/') and n.endswith(('.RSA','.EC','.DSA')) for n in z.namelist()): raise RuntimeError('AAB is unsigned')
        subprocess.run(['jarsigner','-verify',str(artifact)],check=True,stdout=subprocess.DEVNULL)
        print('Built production AAB. Complete device tests, consent tests and Play Console review before publication.')
    finally:
        for path,contents in backups.items(): path.write_bytes(contents)
    return 0
def family_website(config,out):
    out.mkdir(parents=True,exist_ok=True)
    name=html.escape(config['publisher_name']);email=html.escape(config['contact_email'])
    style='<style>body{max-width:780px;margin:48px auto;padding:0 24px;background:#080d1e;color:#eff3ff;font:18px/1.7 system-ui}a,h1,h2{color:#63e8e0}nav{margin-bottom:2em}</style>'
    policy=f'''<!doctype html><html lang="pl"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Neon Block Master — Prywatność</title>{style}<body><nav><a href="index.html">Neon Block Master</a> · <a href="#english">English</a></nav><h1>Polityka prywatności</h1><p>Wersja aplikacji: 1.2.0, wydanie bez reklam.</p><p>Wydawca: {name}<br>Kontakt: <a href="mailto:{email}">{email}</a></p><h2>Dzieci i dorośli</h2><p>Gra jest przeznaczona dla dzieci i dorosłych. Ocena treści w sklepie wynika z ankiety IARC i nie jest deklarowana automatycznie. Ta wersja nie zawiera reklam ani natywnego SDK reklamowego Google, nie oferuje zakupów ani losowych płatnych nagród.</p><h2>Dane lokalne</h2><p>Wyniki, statystyki, monety, odblokowane motywy, efekty, ustawienia, daty odebrania nagród, postęp wyzwań i aktualna rozgrywka są zapisywane na urządzeniu. Starsze zapisy mogą zawierać postęp NEON LAB i identyfikator odebranego bonusu; są zachowywane przy aktualizacji. Gra nie wysyła tych danych na serwer. Nie wymaga konta, imienia, daty urodzenia, kontaktów, zdjęć, mikrofonu ani lokalizacji GPS. W wydaniu bez reklam nie pytamy o wiek. Nie stosujemy własnej analityki ani reklamowych identyfikatorów.</p><h2>Usunięcie i przechowywanie</h2><p>Dane pozostają do wyczyszczenia danych aplikacji lub odinstalowania. Lokalna kopia służy odzyskaniu zapisu po uszkodzeniu. Nie ma synchronizacji między urządzeniami; automatyczna kopia Android jest wyłączona. Wydawca nie ma dostępu do lokalnego zapisu.</p><h2>Kontakt i strona internetowa</h2><p>Rodzic lub opiekun może skontaktować się z wydawcą pod powyższym adresem. Nie przesyłaj danych dziecka ani dokumentów. E-mail może być przetwarzany przez dostawcę poczty wyłącznie w celu odpowiedzi na korespondencję, zgodnie z jego warunkami i prawem właściwym dla wydawcy. Korzystanie z tej strony ujawnia jej hostingowi techniczne dane żądania, np. adres IP; nie dodajemy skryptów śledzących ani cookies reklamowych. Strona jest przygotowana do hostowania w GitHub Pages: <a href="https://docs.github.com/en/site-policy/privacy-policies/github-general-privacy-statement">polityka hostingu GitHub</a>.</p><h2>Zmiany</h2><p>Przed wydaniem z reklamami ta polityka, zgody i deklaracje sklepu muszą zostać ponownie zaktualizowane. Sam plik app-ads.txt nie oznacza, że aplikacja obecnie wyświetla reklamy.</p><hr><section lang="en" id="english"><h1>Privacy policy</h1><p>Publisher: {name}. Contact: {email}. App version 1.2.0, ad-free edition for children and adults.</p><p>Scores, coins, themes, preferences, challenge progress and the current run are stored locally. Migrated saves may retain NEON LAB progress and a bonus receipt. The game sends no progress to a server and requires no account, name, date of birth, contacts, photos, microphone or GPS location. This ad-free edition does not ask your age, include the native Google advertising SDK, show ads, offer purchases or use our own analytics.</p><p>Clear app storage or uninstall to remove local data. A local backup helps recover corrupt saves; cloud backup and synchronization are disabled. Parents/guardians can contact the publisher; do not send child identity details. Email is handled only for correspondence through its provider. Website hosting may receive technical request information such as IP addresses; this site adds no tracking scripts or advertising cookies. A future advertising edition would require an updated policy and appropriate consent and store disclosures.</p></section></body></html>'''
    (out/'privacy.html').write_text(policy)
    (out/'index.html').write_text(f'''<!doctype html><html lang="pl"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Neon Block Master — Krystian Development</title>{style}<body><h1>Neon Block Master</h1><p>Neonowe puzzle dla dzieci i dorosłych.</p><p>Classic · Time Attack · Daily Challenge</p><p>Wydanie 1.2.0: gra offline bez reklam i zakupów. Układaj klocki, usuwaj linie i zdobywaj motywy za monety z rozgrywki.</p><p>{name}<br><a href="mailto:{email}">{email}</a></p><p><a href="privacy.html">Polityka prywatności / Privacy policy</a></p><p>Ocena treści w Google Play zostanie określona przez ankietę IARC. Nie deklarujemy zatwierdzenia aplikacji przez sklep.</p></body></html>''')
    app_id=config.get('admob',{}).get('app_id','')
    match=re.fullmatch(r'ca-app-pub-(\d{16})~\d{10}',app_id)
    if match and match[1]!=TEST_PUBLISHER:
        (out/'app-ads.txt').write_text(f'google.com, pub-{match[1]}, DIRECT, f08c47fec0942fa0\n')
    (out/'.nojekyll').touch()

if __name__=='__main__': sys.exit(main())
