extends Node
## SDK adapter is loaded only on Android with the actual native singletons.
## No simulated impressions or rewards. Entitlement can later be set by verified Billing.
signal availability_changed
signal fullscreen_changed(active: bool)
var adapter: Node
var dragging := false
var fullscreen := false
var last_interstitial := -10000
var last_reward := -10000
var completed_games := 0
var was_available := false

func _ready() -> void:
	if not AppConfig.ads_allowed(): return
	if OS.get_name() != "Android" or not Engine.has_singleton("PoingGodotAdMob"): return
	var sdk = load("res://scripts/admob_adapter.gd")
	if sdk == null: return
	adapter = sdk.new()
	add_child(adapter)
	adapter.changed.connect(func(): availability_changed.emit())
	adapter.visibility.connect(func(active):
		fullscreen = active
		fullscreen_changed.emit(active))
	adapter.initialize()

func reward_available() -> bool:
	return adapter != null and adapter.rewarded != null and not dragging and not fullscreen and Time.get_ticks_msec()/1000-last_reward >= 60

func reward(callback: Callable) -> bool:
	if not reward_available(): return false
	last_reward = Time.get_ticks_msec()/1000
	adapter.show_reward(callback)
	return true

func between_games() -> void:
	completed_games += 1
	if Store.data.ad_free or dragging or fullscreen or adapter == null: return
	if completed_games % 3 != 0 or Time.get_ticks_msec()/1000-last_interstitial < 180: return
	if adapter.interstitial == null: return
	last_interstitial = Time.get_ticks_msec()/1000
	adapter.show_interstitial()

func privacy() -> void:
	if adapter != null: adapter.privacy()

func _process(_delta: float) -> void:
	if adapter == null: return
	var available := reward_available()
	if available != was_available:
		was_available = available
		availability_changed.emit()
