# Neon Block Master – Puzzle

Short description (under 80 characters):
Neon blocks, three ways to play, and a fresh daily challenge. Find your flow!

## Full description

Find your neon flow. Drag blocks onto an 8 × 8 board, fill rows and columns, then chain your clears into satisfying combos.

Choose your challenge:
• Classic — play at your own pace and chase a new personal best.
• Time Attack — three minutes to score; clear multiple lines to earn extra seconds.
• Daily Challenge — a fresh goal every day and a calendar of your achievements.

Earn Neon Coins through daily challenges, daily visits, and new records. Unlock Aurora and Sunset themes or the Orbit effect. In NEON LAB, unlock PLASMA with three optional rewarded ads or 240 coins earned by playing; progress never expires. Pick the reward you want, with no random draws.

Enjoy original electronic music, glowing effects, and clear placement previews. Toggle sounds and vibrations whenever you want. Play in English or Polish.

Play offline with automatic progress saving on your device. Includes optional rewarded ads and limited ads between games; ads require an internet connection. No in-app purchases.

No account. No game server. Just your board and your next great move.


Publisher note (exclude from store description): draft for the advertising edition. The 1.3.1 APK uses official Google test units and earns no revenue. Device tests, current Families SDK verification, hosted privacy policy, Play disclosures and signing are still required before production. Intended for children aged 3 and above and adults; IARC determines the content rating.
