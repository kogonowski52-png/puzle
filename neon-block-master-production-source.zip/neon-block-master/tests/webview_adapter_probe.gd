extends "res://scripts/admob_adapter.gd"
var init_calls := 0
func initialize(): init_calls += 1
