extends Node
## Poing 5.1.0. Real SDK only; UMP errors keep advertising disabled.
signal changed
signal visibility(active: bool)
var rewarded: RewardedAd
var interstitial: InterstitialAd
var initialized := false
var consent_ready := false
var consent_busy := false
var generation := 0
var reward_loading := false
var interstitial_loading := false
var retry_reward_at := 0.0
var retry_interstitial_at := 0.0
var retry_consent_at := 0.0
var reward_failures := 0
var interstitial_failures := 0
var consent_failures := 0
var reward_loaded_at := 0.0
var interstitial_loaded_at := 0.0
var initialization_listener := OnInitializationCompleteListener.new()

func now() -> float:
	return Time.get_ticks_msec()/1000.0

func initialize() -> void:
	if consent_busy or not AppConfig.ads_allowed(): return
	if not Engine.has_singleton("PoingGodotAdMobConsentInformation"): return
	consent_busy = true
	retry_consent_at = 0
	var params := ConsentRequestParameters.new()
	params.tag_for_under_age_of_consent = not AppConfig.audience_configured() # Unknown test audience: conservative privacy flags.
	UserMessagingPlatform.consent_information.update(params,_consent_updated,func(_error):
		consent_busy = false
		consent_failures += 1
		retry_consent_at = now()+minf(300,60*pow(2,mini(3,consent_failures-1)))
		changed.emit())

func _consent_updated() -> void:
	consent_busy = false
	consent_failures = 0
	var info := UserMessagingPlatform.consent_information
	if info.get_consent_status() == ConsentInformation.ConsentStatus.REQUIRED:
		if info.get_is_consent_form_available():
			UserMessagingPlatform.load_consent_form(func(form):
				visibility.emit(true)
				form.show(func(error):
					visibility.emit(false)
					if error == null: _enable_if_allowed()),func(_error): changed.emit())
	else: _enable_if_allowed()

func _enable_if_allowed() -> void:
	var status := UserMessagingPlatform.consent_information.get_consent_status()
	consent_ready = status in [ConsentInformation.ConsentStatus.NOT_REQUIRED,ConsentInformation.ConsentStatus.OBTAINED]
	if not consent_ready: return
	if initialized:
		load_rewarded()
		load_interstitial()
		return
	var request := RequestConfiguration.new()
	request.max_ad_content_rating = RequestConfiguration.MAX_AD_CONTENT_RATING_T
	request.tag_for_child_directed_treatment = RequestConfiguration.TagForChildDirectedTreatment.FALSE if AppConfig.audience_configured() else RequestConfiguration.TagForChildDirectedTreatment.UNSPECIFIED
	request.tag_for_under_age_of_consent = RequestConfiguration.TagForUnderAgeOfConsent.FALSE if AppConfig.audience_configured() else RequestConfiguration.TagForUnderAgeOfConsent.TRUE
	MobileAds.set_request_configuration(request)
	initialization_listener.on_initialization_complete = func(_status):
		initialized = true
		if consent_ready:
			load_rewarded()
			load_interstitial()
	MobileAds.initialize(initialization_listener)

func load_rewarded() -> void:
	if not consent_ready or reward_loading or rewarded != null: return
	reward_loading = true
	var epoch := generation
	var callback := RewardedAdLoadCallback.new()
	callback.on_ad_failed_to_load = func(_error):
		if epoch != generation: return
		reward_loading = false
		reward_failures += 1
		retry_reward_at = now()+minf(300,15*pow(2,mini(5,reward_failures-1)))
		changed.emit()
	callback.on_ad_loaded = func(ad):
		if epoch != generation or not consent_ready:
			ad.destroy()
			return
		reward_loading = false
		reward_failures = 0
		retry_reward_at = 0
		rewarded = ad
		reward_loaded_at = now()
		changed.emit()
	RewardedAdLoader.new().load(AppConfig.ad_id("rewarded"),AdRequest.new(),callback)

func load_interstitial() -> void:
	if not consent_ready or interstitial_loading or interstitial != null: return
	interstitial_loading = true
	var epoch := generation
	var callback := InterstitialAdLoadCallback.new()
	callback.on_ad_failed_to_load = func(_error):
		if epoch != generation: return
		interstitial_loading = false
		interstitial_failures += 1
		retry_interstitial_at = now()+minf(300,15*pow(2,mini(5,interstitial_failures-1)))
		changed.emit()
	callback.on_ad_loaded = func(ad):
		if epoch != generation or not consent_ready:
			ad.destroy()
			return
		interstitial_loading = false
		interstitial_failures = 0
		retry_interstitial_at = 0
		interstitial = ad
		interstitial_loaded_at = now()
		changed.emit()
	InterstitialAdLoader.new().load(AppConfig.ad_id("interstitial"),AdRequest.new(),callback)

func show_reward(callback: Callable) -> void:
	if rewarded == null or not consent_ready: return
	var ad := rewarded
	rewarded = null
	var state := {"earned":false,"closed":false}
	var full := FullScreenContentCallback.new()
	var cleanup := func():
		if state.closed: return
		state.closed = true
		ad.full_screen_content_callback = FullScreenContentCallback.new()
		ad.destroy()
		visibility.emit(false)
		load_rewarded()
	full.on_ad_dismissed_full_screen_content = cleanup
	full.on_ad_failed_to_show_full_screen_content = func(_error): cleanup.call()
	ad.full_screen_content_callback = full
	var earned := OnUserEarnedRewardListener.new()
	earned.on_user_earned_reward = func(_item):
		if state.earned: return
		state.earned = true
		if callback.is_valid(): callback.call()
	visibility.emit(true)
	ad.show(earned)
	changed.emit()

func show_interstitial() -> void:
	if interstitial == null or not consent_ready: return
	var ad := interstitial
	interstitial = null
	var state := {"closed":false}
	var full := FullScreenContentCallback.new()
	var cleanup := func():
		if state.closed: return
		state.closed = true
		ad.full_screen_content_callback = FullScreenContentCallback.new()
		ad.destroy()
		visibility.emit(false)
		load_interstitial()
	full.on_ad_dismissed_full_screen_content = cleanup
	full.on_ad_failed_to_show_full_screen_content = func(_error): cleanup.call()
	ad.full_screen_content_callback = full
	visibility.emit(true)
	ad.show()

func privacy() -> void:
	generation += 1
	consent_ready = false
	reward_loading = false
	interstitial_loading = false
	retry_reward_at = 0
	retry_interstitial_at = 0
	if rewarded != null:
		rewarded.destroy()
		rewarded = null
	if interstitial != null:
		interstitial.destroy()
		interstitial = null
	changed.emit()
	var requirement := UserMessagingPlatform.consent_information.get_privacy_options_requirement_status()
	if requirement != ConsentInformation.PrivacyOptionsRequirementStatus.REQUIRED:
		initialize()
		return
	visibility.emit(true)
	UserMessagingPlatform.show_privacy_options_form(func(error):
		visibility.emit(false)
		if error == null: _enable_if_allowed())

func _process(_delta: float) -> void:
	var time := now()
	if retry_consent_at > 0 and time >= retry_consent_at: initialize()
	if not consent_ready: return
	# Google ads expire after one hour. Refresh before that deadline.
	if rewarded != null and time-reward_loaded_at >= 3000:
		rewarded.destroy()
		rewarded = null
		retry_reward_at = time
		changed.emit()
	if interstitial != null and time-interstitial_loaded_at >= 3000:
		interstitial.destroy()
		interstitial = null
		retry_interstitial_at = time
	if retry_reward_at > 0 and time >= retry_reward_at:
		retry_reward_at = 0
		load_rewarded()
	if retry_interstitial_at > 0 and time >= retry_interstitial_at:
		retry_interstitial_at = 0
		load_interstitial()
