# Neon Block Master – Puzzle

Short description (under 80 characters):
Neon blocks, three ways to play, and a fresh daily challenge. Find your flow!

## Full description

Find your neon flow. Drag blocks onto an 8 × 8 board, fill rows and columns, then chain your clears into satisfying combos.

Choose your challenge:
• Classic — play at your own pace and chase a new personal best.
• Time Attack — three minutes to score; clear multiple lines to earn extra seconds.
• Daily Challenge — a fresh goal every day and a calendar of your achievements.

Earn Neon Coins through daily challenges, daily visits, and new records. Unlock Aurora and Sunset themes or the Orbit effect. In NEON LAB, unlock PLASMA with coins or three optional rewarded ads; progress never expires. After a run, optionally double the coins you earned when an ad is available. Pick the reward you want, with no random draws.

Enjoy original electronic music, glowing effects, and clear placement previews. Toggle sounds and vibrations whenever you want. Play in English or Polish.

Play offline with automatic progress saving on your device. Ads require an internet connection. Extra coins and a second chance are optional rewarded ad offers when available. Full-screen ads appear only between games.

No account. No game server. Just your board and your next great move.

Publisher note: this copy describes the ad-enabled version. Remove this note and match the Play “Contains ads” declaration to the final artifact. No remove-ads purchase is offered; Billing is not implemented.
