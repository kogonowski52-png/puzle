# Neon Block Master – Puzzle

Krótki opis (do 80 znaków):
Neonowe klocki, trzy tryby i codzienne wyzwania. Znajdź swój rytm!

## Pełny opis

Wejdź w neonowy rytm! Przeciągaj figury na planszę 8 × 8, wypełniaj rzędy i kolumny, a potem połącz kolejne trafienia w satysfakcjonujące combo.

Wybierz swój sposób gry:
• Classic — spokojna rozgrywka bez limitu czasu i walka o własny rekord.
• Time Attack — trzy minuty na wynik; usuwaj wiele linii, aby zyskać cenne sekundy.
• Daily Challenge — nowe zadanie każdego dnia i kalendarz Twoich sukcesów.

Zdobywaj Neon Coins za wyzwania, codzienne uruchomienie gry i nowe rekordy. Odblokuj motywy Aurora i Sunset oraz efekt Orbit. W NEON LAB odblokuj PLASMA za monety zdobyte w grze; postęp nie wygasa. Wybierasz konkretną nagrodę — bez losowania.

Ciesz się oryginalną elektroniczną muzyką, świetlnymi efektami i czytelnym podglądem ruchu. Wyłącz dźwięki lub wibracje, gdy potrzebujesz ciszy. Interfejs dostępny po polsku i angielsku.

Gra działa offline i automatycznie zapisuje Twój postęp na urządzeniu. Wydanie 1.2.0 działa bez reklam i zakupów.

Bez konta. Bez serwera gry. Po prostu Twoja plansza i kolejny dobry ruch.


Nota wydawnicza: opis dotyczy 1.2.0 bez reklam. Ocena treści zostanie określona przez IARC; nie deklarujemy automatycznie 3+.
