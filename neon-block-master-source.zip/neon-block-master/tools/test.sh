#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
# Keep test progress isolated from the real player's save.
test_data=$(mktemp -d)
trap 'rm -rf "$test_data"' EXIT
XDG_DATA_HOME="$test_data" godot --headless --path . --script tests/run.gd
python3 -m unittest discover -s tests -p 'test_release.py'
