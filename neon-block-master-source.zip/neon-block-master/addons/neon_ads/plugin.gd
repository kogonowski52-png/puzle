# SPDX-License-Identifier: MIT
# Copyright (c) 2026 Neon Block Master contributors.
@tool
extends EditorPlugin
var android_exporter = preload("res://addons/neon_ads/android_export.gd").new()
var registered := false
func _enter_tree() -> void:
	var config = JSON.parse_string(FileAccess.get_file_as_string("res://assets/app_config.json"))
	if config is Dictionary and config.get("ads_enabled",false) and config.get("ad_profile","")=="family_contextual" and config.get("ad_sdk","")=="gma_classic_24.9.0":
		add_export_plugin(android_exporter)
		registered = true
func _exit_tree() -> void:
	if registered: remove_export_plugin(android_exporter)
